﻿namespace Practicav2
{
    partial class ejer3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstconverde = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstconvera = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bntconvertir = new System.Windows.Forms.Button();
            this.btnsalir = new System.Windows.Forms.Button();
            this.txtconversion = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtotro = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Introduzca la longitud a convertir";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstconverde);
            this.groupBox1.Location = new System.Drawing.Point(69, 184);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 112);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "De";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lstconverde
            // 
            this.lstconverde.FormattingEnabled = true;
            this.lstconverde.Items.AddRange(new object[] {
            "Pulgadas",
            "Pies",
            "Yardas"});
            this.lstconverde.Location = new System.Drawing.Point(25, 19);
            this.lstconverde.Name = "lstconverde";
            this.lstconverde.Size = new System.Drawing.Size(123, 56);
            this.lstconverde.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstconvera);
            this.groupBox2.Location = new System.Drawing.Point(328, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(178, 112);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "a";
            // 
            // lstconvera
            // 
            this.lstconvera.FormattingEnabled = true;
            this.lstconvera.Items.AddRange(new object[] {
            "Pulgadas",
            "Pies",
            "Yardas"});
            this.lstconvera.Location = new System.Drawing.Point(31, 19);
            this.lstconvera.Name = "lstconvera";
            this.lstconvera.Size = new System.Drawing.Size(126, 56);
            this.lstconvera.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Longitud convertida";
            // 
            // bntconvertir
            // 
            this.bntconvertir.Location = new System.Drawing.Point(134, 402);
            this.bntconvertir.Name = "bntconvertir";
            this.bntconvertir.Size = new System.Drawing.Size(141, 32);
            this.bntconvertir.TabIndex = 1;
            this.bntconvertir.Text = "Convertir";
            this.bntconvertir.UseVisualStyleBackColor = true;
            this.bntconvertir.Click += new System.EventHandler(this.bntconvertir_Click);
            // 
            // btnsalir
            // 
            this.btnsalir.Location = new System.Drawing.Point(328, 402);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(141, 32);
            this.btnsalir.TabIndex = 2;
            this.btnsalir.Text = "Salir";
            this.btnsalir.UseVisualStyleBackColor = true;
            // 
            // txtconversion
            // 
            this.txtconversion.Enabled = false;
            this.txtconversion.Location = new System.Drawing.Point(174, 360);
            this.txtconversion.Name = "txtconversion";
            this.txtconversion.Size = new System.Drawing.Size(112, 20);
            this.txtconversion.TabIndex = 6;
            this.txtconversion.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // txtotro
            // 
            this.txtotro.Location = new System.Drawing.Point(263, 59);
            this.txtotro.Name = "txtotro";
            this.txtotro.Size = new System.Drawing.Size(154, 20);
            this.txtotro.TabIndex = 0;
            this.txtotro.Validating += new System.ComponentModel.CancelEventHandler(this.txtotro_Validating);
            this.txtotro.Validated += new System.EventHandler(this.txtotro_Validated);
            // 
            // ejer3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 450);
            this.Controls.Add(this.txtotro);
            this.Controls.Add(this.txtconversion);
            this.Controls.Add(this.btnsalir);
            this.Controls.Add(this.bntconvertir);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "ejer3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.ejer3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bntconvertir;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.TextBox txtconversion;
        private System.Windows.Forms.ListBox lstconverde;
        private System.Windows.Forms.ListBox lstconvera;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox txtotro;
    }
}