﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practicav2
{
    public partial class ejer2 : Form
    {
        public ejer2()
        {
            InitializeComponent();
            rdo0.Checked = true;

        }
        private int cantidad;
        private double precio;
        private void groupBox1_Enter(object sender, EventArgs e)
            
        {

        }

        private void txtcan_Validating(object sender, CancelEventArgs e)
        {
         try
            { 
            cantidad = Convert.ToInt32(txtcan.Text);
                errorProvider1.Clear();
            }
            catch(Exception)
            {
                e.Cancel = true;
                txtcan.SelectAll();
                errorProvider1.SetError(txtcan, "ingrese solo numeros");
            }
        }

        private void txtcan_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpre_Validating(object sender, CancelEventArgs e)
        {
            try
            {
               precio = Convert.ToInt32(txtpre.Text);
                if(precio<=0)
                {
                    e.Cancel = true;
                    txtpre.SelectAll();
                    errorProvider1.SetError(txtpre, "Ingrese solo numeros mayores a 0");
                }
                
                
            }
            catch (Exception)
            {
                e.Cancel = true;
                txtpre.SelectAll();
                errorProvider1.SetError(txtpre, "ingrese solo numeros");
            }
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double multi = Convert.ToDouble(txtcan.Text)*Convert.ToDouble(txtpre.Text);
            double descuento = 0;
            if(rdo0.Checked)
            {
                descuento = 0;
                txtdes.Text = Convert.ToString(descuento);
                txttotal.Text = Convert.ToString(multi);
            }
            else if(rdo5.Checked)
            {
                descuento = multi*0.05;
                txtdes.Text = Convert.ToString(descuento);
                multi = multi - descuento;
                txttotal.Text = Convert.ToString(multi);
            }
            else if (rdo10.Checked)
            {
                descuento = multi * 0.10;
                txtdes.Text = Convert.ToString(descuento);
                multi = multi - descuento;
                txttotal.Text = Convert.ToString(multi);
            }
            else if (rdo15.Checked)
            {
                descuento = multi * 0.15;
                txtdes.Text = Convert.ToString(descuento);
                multi = multi - descuento;
                txttotal.Text = Convert.ToString(multi);
            }
            else if (rdo20.Checked)
            {
                descuento = multi * 0.20;
                txtdes.Text = Convert.ToString(descuento);
                multi = multi - descuento;
                txttotal.Text = Convert.ToString(multi);
            }
        }

        private void txtpre_Validated(object sender, EventArgs e)
        {
           
            
                errorProvider1.Clear();
            
        }

        private void ejer2_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }

        private void rdo0_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtcan.Clear();
            txtpre.Clear();
            txtdes.Clear();
            txttotal.Clear();
            rdo0.Checked = true;
        }
    }
}
