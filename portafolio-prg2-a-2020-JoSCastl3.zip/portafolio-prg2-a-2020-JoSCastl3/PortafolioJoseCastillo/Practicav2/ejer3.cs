﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practicav2
{
    public partial class ejer3 : Form
    {
        public ejer3()
        {
            InitializeComponent();


        }
        double dato;



        private void ejer3_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void txtotro_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                dato = Convert.ToDouble(txtotro.Text);
                if (dato < 0)
                {
                    e.Cancel = true;
                    txtotro.SelectAll();
                    errorProvider1.SetError(txtotro, "introduzca solo numeros mayores a 0");
                }

            }
            catch (Exception)

            {
                e.Cancel = true;
                txtotro.SelectAll();
                errorProvider1.SetError(txtotro, "introduzca solo numeros");
            }
        }

        private void txtotro_Validated(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtdato_Validated(object sender, EventArgs e)
        {

        }

        private void bntconvertir_Click(object sender, EventArgs e)
        {
            double dato = Convert.ToDouble(txtotro.Text);
            string converde = lstconverde.Text;
            string convera = lstconvera.Text;

            if (converde == "Pulgadas")
            {
                if (convera == "Pulgadas")
                {
                    dato = dato*1;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Pies")
                {
                    dato = dato * 0.833333;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Yardas")
                {
                    dato = dato * 0.0278;
                    txtconversion.Text = Convert.ToString(dato);
                }
            }
            else if (converde == "Pies")
            {

                if (convera == "Pulgadas")
                {
                    dato = dato * 12;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Pies")
                {
                    dato = dato + 0;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Yardas")
                {
                    dato = dato * 0.333333;
                    txtconversion.Text = Convert.ToString(dato);
                }
            }
            if (converde == "Yardas")
            {

                if (convera == "Pulgadas")
                {
                    dato = dato * 36;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Pies")
                {
                    dato = dato * 3;
                    txtconversion.Text = Convert.ToString(dato);
                }
                else if (convera == "Yardas")
                {
                    dato = dato + 0;
                    txtconversion.Text = Convert.ToString(dato);
                }
            }

        }
    }


}


