﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practicav2
{
    public partial class ejer1 : Form
    {
        public ejer1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bntconver_Click(object sender, EventArgs e)
        {
            try
            {
             
                lblmostrar.Text = "Esperando que ingrese numero en el rango 1-10";
                int numero = Convert.ToInt32(txtnumero.Text);
                string romano = "";
               
                switch (numero)
                {
                    case 1:
                        romano = "I";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 2:
                        romano = "II";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 3:
                        romano = "III";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 4:
                        romano = "VI";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 5:
                        romano = "V";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 6:
                        romano = "VI";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 7:
                        romano = "VII";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 8:
                        romano = "VIII";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 9:
                        romano = "IX";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                    case 10:
                        romano = "X";
                        lblmostrar.Text = "El numero:" + numero + "en romano es:" + romano;
                        return;
                }
              
            }
            catch (Exception)
            {
                MessageBox.Show("ingrese solo numeros");
                txtnumero.Clear();
                lblmostrar.Text = "ingrese datos";
            }
        }

        private void txtnumero_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
