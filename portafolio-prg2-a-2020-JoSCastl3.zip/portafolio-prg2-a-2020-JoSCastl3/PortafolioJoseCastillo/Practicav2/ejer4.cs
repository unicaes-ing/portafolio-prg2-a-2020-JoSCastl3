﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Practicav2
{
    public partial class ejer4 : Form
    {
        public ejer4()
        {
            InitializeComponent();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            string correo = @"\A(\w+\.?\w*\@\w+\.)(com)\Z";
            if (Regex.IsMatch(txtcorreo.Text, correo) == false)
            {
                e.Cancel = true;
                txtcorreo.SelectAll();
                errorProvider1.SetError(txtcorreo, "el correo debe ser nombre@dominio.com");
            }
        }

        private void ejer4_Load(object sender, EventArgs e)
        {

        }

        private void ejer4_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }

        private void txtcorreo_Validated(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void txtcorreo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcontra_Validating(object sender, CancelEventArgs e)
        {
            string contra = @"^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$";


            if (!Regex.IsMatch(txtcontra.Text, contra))
            {
                e.Cancel = true;
                txtcontra.SelectAll();
                errorProvider1.SetError(txtcontra, "La contra debe tener al menos mass  de 8 caracteres" + "\n 1 letra mayuscula" + "\n 1 letra minuscula");
            }

        }

        private void txtcontra_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcontra_Validated(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            bool validar = true;
            errorProvider1.Clear();
            if(txtcontra.Text==txtrecontra.Text)
            {
                validar = true;
            }
            else
            {
                validar = false;
                errorProvider1.SetError(txtrecontra, "la contraseña no son iguales");
            }
            if(validar)
            {
                MessageBox.Show("Los datos se han guardado");
            }
        }
    }
}
