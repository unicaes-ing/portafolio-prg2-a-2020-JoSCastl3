﻿namespace Practica3
{
    partial class ejer3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstnumber = new System.Windows.Forms.ListBox();
            this.btnlanzar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstnumber
            // 
            this.lstnumber.FormattingEnabled = true;
            this.lstnumber.Location = new System.Drawing.Point(71, 46);
            this.lstnumber.Name = "lstnumber";
            this.lstnumber.Size = new System.Drawing.Size(92, 316);
            this.lstnumber.TabIndex = 0;
            // 
            // btnlanzar
            // 
            this.btnlanzar.Location = new System.Drawing.Point(71, 377);
            this.btnlanzar.Name = "btnlanzar";
            this.btnlanzar.Size = new System.Drawing.Size(76, 23);
            this.btnlanzar.TabIndex = 1;
            this.btnlanzar.Text = "Lanzar";
            this.btnlanzar.UseVisualStyleBackColor = true;
            this.btnlanzar.Click += new System.EventHandler(this.btnlanzar_Click);
            // 
            // ejer3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(235, 450);
            this.Controls.Add(this.btnlanzar);
            this.Controls.Add(this.lstnumber);
            this.Name = "ejer3";
            this.Text = "ejer3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstnumber;
        private System.Windows.Forms.Button btnlanzar;
    }
}