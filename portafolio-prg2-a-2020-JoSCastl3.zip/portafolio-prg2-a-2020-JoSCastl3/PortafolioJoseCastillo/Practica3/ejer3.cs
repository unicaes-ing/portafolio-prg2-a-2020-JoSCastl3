﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class ejer3 : Form
    {
        public ejer3()
        {
            InitializeComponent();
        }

        private void btnlanzar_Click(object sender, EventArgs e)
        {
            lstnumber.Items.Clear();
            Random r = new Random();
            int conteo = 0;
            int numeros = 0;
            int repeticion = 0;
            int cantidad = 5001;
            while (conteo < cantidad)
            {
                numeros = r.Next(5000);
                lstnumber.Items.Add(numeros);
                if(numeros==6)
                {
                    repeticion = repeticion + 1;
                }
                conteo = conteo + 1;
            }
            MessageBox.Show("la cantidad de veces que se repitio el 6 fue "+repeticion);
        }
    }
}
