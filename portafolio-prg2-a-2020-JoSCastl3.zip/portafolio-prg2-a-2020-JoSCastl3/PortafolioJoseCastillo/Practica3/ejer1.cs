﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class ejer1 : Form
    {
        public ejer1()
        {
            InitializeComponent();
        }
        int num;
        private void txttabla_Validating(object sender, CancelEventArgs e)
        {
            try
            {

                num = Convert.ToInt32(txttabla.Text);
            }
            catch (Exception)
            {
                e.Cancel = true;
                txttabla.SelectAll();
                errorProvider1.SetError(txttabla, "ingrese solo numero");
            }
        }

        private void txttabla_Validated(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }
        private void btngenerar_Click(object sender, EventArgs e)
        {
            lsttabla.Items.Clear();
            int tabla = Convert.ToInt32(txttabla.Text);
            int multi = 0;
            for (int i = 1; i < 11; i++)
            {
                multi = tabla * i;
                lsttabla.Items.Add(tabla + "x" + i + "=" + multi);
            }
        }

        private void txttabla_TextChanged(object sender, EventArgs e)
        {

        }

       
    }
}
