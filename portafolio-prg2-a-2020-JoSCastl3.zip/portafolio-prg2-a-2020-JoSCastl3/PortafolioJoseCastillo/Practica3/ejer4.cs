﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class ejer4 : Form
    {
        public ejer4()
        {
            InitializeComponent();
        }

        private void ejer4_Load(object sender, EventArgs e)
        {
            dgvnumeros.Size = new Size(210, 220);
            dgvnumeros.AllowUserToAddRows = false;
            dgvnumeros.ScrollBars = ScrollBars.None;
        }
    }
}
