﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Practica3
{
    public partial class ejer5 : Form
    {
        public ejer5()
        {
            InitializeComponent();
        }

        private void txtnombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txthora_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtvalor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            bool validar = true;
            erroringreso.Clear();
            if (txtnombre.Text == "")
            {
                erroringreso.SetError(txtnombre, "ingrese nombre");
                validar = false;
            }
            else
            {
                string nombre = @"^([A-Z]{1}[a-zñ]{2,}(\s)){3,5}[A-Z]{1}[a-zñ]{2,}$";
                if (!Regex.IsMatch(txtnombre.Text, nombre))
                {
                    erroringreso.SetError(txtnombre, "nombre invalido");
                    validar = false;
                }

            }
            if (txthora.Text == "")
            {
                validar = false;
                erroringreso.SetError(txthora, "ingrese horas trabajadas");
            }
            else
            {
                string hora = @"^[0-9]{1,5}$";
                if (!Regex.IsMatch(txthora.Text, hora))
                {
                    validar = false;
                    erroringreso.SetError(txthora, "Las horas son muy exageradas");
                }
            }
            if (txtvalor.Text == "")
            {
                validar = false;
                erroringreso.SetError(txtvalor, "ingrese valor");
            }
            else
            {
                string valor = @"^[0-9]{1,}\.[0-9]{2}$";
                if (!Regex.IsMatch(txtvalor.Text, valor))
                {
                    validar = false;
                    erroringreso.SetError(txtvalor, "El valor es incorrrecto 00.00");
                }
            }

            if (validar)
                {
                double valorh = Convert.ToDouble(txtvalor.Text);
                int Horas = Convert.ToInt32(txthora.Text);
                double impuesto = (Horas * valorh) * 0.10;
                double subtotal = (Horas * valorh);
                double Total = subtotal - impuesto;
                double sumatotal = 0;
                sumatotal = sumatotal + Total;
                dgvplanilla.Rows.Add(txtnombre.Text,Horas,valorh,subtotal,impuesto,Total);
                lblplanilla.Text = "Total planilla =" + sumatotal;
                txtnombre.Clear();
                txtvalor.Clear();
                txthora.Clear();
                }
            
        }

        private void ejer5_Load(object sender, EventArgs e)
        {

        }

        private void btsalir_Click(object sender, EventArgs e)
        {
            dgvplanilla.Rows.Clear();
        }
    }
}
