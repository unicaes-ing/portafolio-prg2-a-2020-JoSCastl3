﻿namespace Practica3
{
    partial class ejer1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txttabla = new System.Windows.Forms.TextBox();
            this.lsttabla = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btngenerar = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // txttabla
            // 
            this.txttabla.Location = new System.Drawing.Point(61, 72);
            this.txttabla.Name = "txttabla";
            this.txttabla.Size = new System.Drawing.Size(145, 20);
            this.txttabla.TabIndex = 0;
            this.txttabla.TextChanged += new System.EventHandler(this.txttabla_TextChanged);
            this.txttabla.Validating += new System.ComponentModel.CancelEventHandler(this.txttabla_Validating);
            this.txttabla.Validated += new System.EventHandler(this.txttabla_Validated);
            // 
            // lsttabla
            // 
            this.lsttabla.FormattingEnabled = true;
            this.lsttabla.Location = new System.Drawing.Point(61, 109);
            this.lsttabla.Name = "lsttabla";
            this.lsttabla.Size = new System.Drawing.Size(144, 173);
            this.lsttabla.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Numero de la tabla";
            // 
            // btngenerar
            // 
            this.btngenerar.Location = new System.Drawing.Point(243, 65);
            this.btngenerar.Name = "btngenerar";
            this.btngenerar.Size = new System.Drawing.Size(83, 27);
            this.btngenerar.TabIndex = 3;
            this.btngenerar.Text = "Generar";
            this.btngenerar.UseVisualStyleBackColor = true;
            this.btngenerar.Click += new System.EventHandler(this.btngenerar_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ejer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 450);
            this.Controls.Add(this.btngenerar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lsttabla);
            this.Controls.Add(this.txttabla);
            this.Name = "ejer1";
            this.Text = "Tabla";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txttabla;
        private System.Windows.Forms.ListBox lsttabla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btngenerar;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

