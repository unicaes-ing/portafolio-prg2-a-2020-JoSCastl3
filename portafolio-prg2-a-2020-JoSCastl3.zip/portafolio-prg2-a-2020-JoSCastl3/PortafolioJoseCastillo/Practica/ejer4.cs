﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica
{
    public partial class ejer4 : Form
    {
        public ejer4()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string libro = cbolibro.Text;
            double precio = 0;
            switch (libro)
            {
                case "Chess ":
                    precio = 7.00;
                    txtprecio.Text = Convert.ToString(precio);
                    return;
                case "Harry potter":
                    precio = 9.00;
                    txtprecio.Text = Convert.ToString(precio);
                    return;
                case "Coraline":
                    precio = 5.00;
                    txtprecio.Text = Convert.ToString(precio);
                    return;
                case "El Olimpo":
                    precio = 10.00;
                    txtprecio.Text = Convert.ToString(precio);
                    return;
                case "La grande aventuras del dios jose":
                    precio = 100.00;
                    txtprecio.Text = Convert.ToString(precio);
                    return;
            }
        }

        private void btncal_Click(object sender, EventArgs e)
        {
            try
            {
                int multipli = Convert.ToInt32(txtcantidad.Text);
                double subtotal = Convert.ToDouble(txtprecio.Text) * multipli;
                txtsub.Text = Convert.ToString(subtotal);
                double impues = subtotal * 0.13;
                txtimpuesto.Text = Convert.ToString(impues);
                double total = subtotal + impues;
                txtpagar.Text = Convert.ToString(total);
            }
            catch (Exception)
            {
                MessageBox.Show("ingrese la cantidad");
            }

        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtcantidad.Clear();
            txtimpuesto.Clear();
            txtpagar.Clear();
            txtprecio.Clear();
            txtsub.Clear();
            cbolibro.SelectedIndex = -1;
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
