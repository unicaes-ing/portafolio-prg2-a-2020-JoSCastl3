﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica
{
    public partial class ejer1 : Form
    {
        public ejer1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                double promedio = (Convert.ToDouble(txtexa1.Text) + Convert.ToDouble(txtExam2.Text) + Convert.ToDouble(txtExam3.Text)) / 3;
                txtPro.Text = Convert.ToString(promedio);
            }
            catch (Exception)
            {
                MessageBox.Show("ingrese solo numeros");
                txtexa1.Clear();
                txtExam2.Clear();
                txtExam3.Clear();
                txtPro.Clear();
            }
        }

        private void btnlim_Click(object sender, EventArgs e)
        {
            txtexa1.Clear();
            txtExam2.Clear();
            txtExam3.Clear();
            txtPro.Clear();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

