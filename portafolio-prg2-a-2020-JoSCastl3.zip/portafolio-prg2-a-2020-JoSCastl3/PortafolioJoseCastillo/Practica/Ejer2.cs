﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica
{
    public partial class Ejer2 : Form
    {
        public Ejer2()
        {
            InitializeComponent();
        }

        private void Ejer2_Load(object sender, EventArgs e)
        {

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int deci = Convert.ToInt32(txtdeci.Text);
                txtbi.Text = Convert.ToString(deci, 2);
                txtoctal.Text = Convert.ToString(deci, 8);
                txthexa.Text = Convert.ToString(deci, 16);
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese solo numeros enteros");
                txtdeci.Clear();
            }
        }

        private void btnclear_Click_1(object sender, EventArgs e)
        {
            txtdeci.Clear();
            txtbi.Clear();
            txtoctal.Clear();
            txthexa.Clear();
        }
        private void btnexit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    
}

