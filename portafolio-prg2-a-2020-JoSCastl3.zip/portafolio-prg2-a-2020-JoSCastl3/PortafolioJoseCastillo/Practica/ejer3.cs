﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica
{
    public partial class ejer3 : Form
    {
        public ejer3()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                string inver1 = txtin1.Text, inver2 = txtin2.Text, inver3 = txtin3.Text;
                double totalpor = 0;
                double porcentaje1 = 0, porcentaje2 = 0, porcentaje3 = 0;
                //cabe recalcar que el ejercicio no decia nada de tipos de porcentajes ni de nombres 
                //a si que todo lo demas no tiene fundamentos
                if (inver1 == "Jose Castillo"|| inver1=="Elias Baños")
                {
                    porcentaje1 = 10;
                }
                else if (inver1=="Jose Baños" || inver1=="Elias Castillo")
                {
                    porcentaje1 = 25;
                }
                else 
                {
                    porcentaje1 = 0;
                }

                if (inver2 == "Jose Castilo" || inver2 == "Elias Baños")
                {
                    porcentaje2 = 10;
                }
                else if (inver2 == "Jose Baños" || inver2 == "Elias Castillo")
                {
                    porcentaje2 = 25;
                }
                else
                {
                    porcentaje2 = 0;
                }
                if (inver3 == "Jose Castillo" || inver3 == "Elias Baños")
                {
                    porcentaje1 = 10;
                }
                else if (inver3 == "Jose Baños" || inver3 == "Elias Castillo")
                {
                    porcentaje3 = 25;
                }
                else
                {
                    porcentaje3 = 0;
                }
                totalpor = porcentaje1 + porcentaje2 + porcentaje3;
                txtpor1.Text = Convert.ToString(porcentaje1);
                txtpor2.Text = Convert.ToString(porcentaje2);
                txtpor3.Text = Convert.ToString(porcentaje3);
                txttotal.Text = Convert.ToString(totalpor);
            }
            catch (Exception)
            {

            }

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtin1.Clear();
            txtin2.Clear();
            txtin3.Clear();
            txtpor1.Clear();
            txtpor2.Clear();
            txtpor3.Clear();
            txttotal.Clear();
        }

        private void btnsallir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
