﻿namespace Practica
{
    partial class ejer1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsalir = new System.Windows.Forms.Button();
            this.btnlim = new System.Windows.Forms.Button();
            this.btncalcular = new System.Windows.Forms.Button();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.txtExam3 = new System.Windows.Forms.TextBox();
            this.txtExam2 = new System.Windows.Forms.TextBox();
            this.txtexa1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnsalir
            // 
            this.btnsalir.Location = new System.Drawing.Point(276, 312);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(75, 21);
            this.btnsalir.TabIndex = 6;
            this.btnsalir.Text = "Salir";
            this.btnsalir.UseVisualStyleBackColor = true;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // btnlim
            // 
            this.btnlim.Location = new System.Drawing.Point(161, 312);
            this.btnlim.Name = "btnlim";
            this.btnlim.Size = new System.Drawing.Size(75, 21);
            this.btnlim.TabIndex = 5;
            this.btnlim.Text = "Limpiar";
            this.btnlim.UseVisualStyleBackColor = true;
            this.btnlim.Click += new System.EventHandler(this.btnlim_Click);
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(48, 312);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 21);
            this.btncalcular.TabIndex = 4;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // txtPro
            // 
            this.txtPro.Enabled = false;
            this.txtPro.Location = new System.Drawing.Point(192, 229);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(100, 20);
            this.txtPro.TabIndex = 3;
            // 
            // txtExam3
            // 
            this.txtExam3.Location = new System.Drawing.Point(192, 152);
            this.txtExam3.Name = "txtExam3";
            this.txtExam3.Size = new System.Drawing.Size(100, 20);
            this.txtExam3.TabIndex = 3;
            // 
            // txtExam2
            // 
            this.txtExam2.Location = new System.Drawing.Point(192, 114);
            this.txtExam2.Name = "txtExam2";
            this.txtExam2.Size = new System.Drawing.Size(100, 20);
            this.txtExam2.TabIndex = 2;
            // 
            // txtexa1
            // 
            this.txtexa1.Location = new System.Drawing.Point(192, 76);
            this.txtexa1.Name = "txtexa1";
            this.txtexa1.Size = new System.Drawing.Size(100, 20);
            this.txtexa1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 236);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Promedio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Examen 3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Examen 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Examen 1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 450);
            this.Controls.Add(this.btnsalir);
            this.Controls.Add(this.btnlim);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.txtPro);
            this.Controls.Add(this.txtExam3);
            this.Controls.Add(this.txtExam2);
            this.Controls.Add(this.txtexa1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Promedio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Button btnlim;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.TextBox txtExam3;
        private System.Windows.Forms.TextBox txtExam2;
        private System.Windows.Forms.TextBox txtexa1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

