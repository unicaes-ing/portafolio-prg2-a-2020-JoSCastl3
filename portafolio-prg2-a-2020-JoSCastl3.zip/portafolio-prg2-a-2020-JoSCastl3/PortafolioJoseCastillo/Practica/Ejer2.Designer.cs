﻿namespace Practica
{
    partial class Ejer2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexit = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btncalcular = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdeci = new System.Windows.Forms.TextBox();
            this.grpconvert = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbi = new System.Windows.Forms.TextBox();
            this.txtoctal = new System.Windows.Forms.TextBox();
            this.txthexa = new System.Windows.Forms.TextBox();
            this.grpconvert.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(325, 382);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(96, 22);
            this.btnexit.TabIndex = 9;
            this.btnexit.Text = "Salir";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click_1);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(175, 382);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(96, 22);
            this.btnclear.TabIndex = 7;
            this.btnclear.Text = "Limpiar";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click_1);
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(33, 382);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(96, 22);
            this.btncalcular.TabIndex = 6;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Decimal:";
            // 
            // txtdeci
            // 
            this.txtdeci.Location = new System.Drawing.Point(132, 47);
            this.txtdeci.Name = "txtdeci";
            this.txtdeci.Size = new System.Drawing.Size(100, 20);
            this.txtdeci.TabIndex = 4;
            // 
            // grpconvert
            // 
            this.grpconvert.Controls.Add(this.label4);
            this.grpconvert.Controls.Add(this.label2);
            this.grpconvert.Controls.Add(this.label3);
            this.grpconvert.Controls.Add(this.txtbi);
            this.grpconvert.Controls.Add(this.txtoctal);
            this.grpconvert.Controls.Add(this.txthexa);
            this.grpconvert.Location = new System.Drawing.Point(60, 149);
            this.grpconvert.Name = "grpconvert";
            this.grpconvert.Size = new System.Drawing.Size(264, 196);
            this.grpconvert.TabIndex = 5;
            this.grpconvert.TabStop = false;
            this.grpconvert.Text = "Equivale a";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Binario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Octal:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Hexadecimal:";
            // 
            // txtbi
            // 
            this.txtbi.Enabled = false;
            this.txtbi.Location = new System.Drawing.Point(115, 43);
            this.txtbi.Name = "txtbi";
            this.txtbi.Size = new System.Drawing.Size(100, 20);
            this.txtbi.TabIndex = 2;
            // 
            // txtoctal
            // 
            this.txtoctal.Enabled = false;
            this.txtoctal.Location = new System.Drawing.Point(115, 102);
            this.txtoctal.Name = "txtoctal";
            this.txtoctal.Size = new System.Drawing.Size(100, 20);
            this.txtoctal.TabIndex = 3;
            // 
            // txthexa
            // 
            this.txthexa.Enabled = false;
            this.txthexa.Location = new System.Drawing.Point(115, 144);
            this.txthexa.Name = "txthexa";
            this.txthexa.Size = new System.Drawing.Size(100, 20);
            this.txthexa.TabIndex = 4;
            // 
            // Ejer2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 450);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdeci);
            this.Controls.Add(this.grpconvert);
            this.Name = "Ejer2";
            this.Text = "Sistemas";
            this.Load += new System.EventHandler(this.Ejer2_Load);
            this.grpconvert.ResumeLayout(false);
            this.grpconvert.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdeci;
        private System.Windows.Forms.GroupBox grpconvert;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbi;
        private System.Windows.Forms.TextBox txtoctal;
        private System.Windows.Forms.TextBox txthexa;
    }
}