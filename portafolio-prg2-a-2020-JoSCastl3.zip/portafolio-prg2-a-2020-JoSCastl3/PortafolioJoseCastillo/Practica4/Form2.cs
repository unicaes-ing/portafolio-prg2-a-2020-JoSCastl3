﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            try
            {
                double numero = Convert.ToDouble(txtnumero.Text);
                lstnumeros.Items.Add(numero);
                txtnumero.Clear();
                txtnumero.Focus();
            }
            catch(Exception)
            {
                MessageBox.Show("Ingrese solo numeros");
            }
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                double buscar = Convert.ToDouble(txtbuscar.Text);
                MessageBox.Show("las veces que se repitio el "+" "+buscar+" "+"fue de "+Convert.ToString(busqueda(buscar,lstnumeros)));
               
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese solo numeros");
            }
        }

        private void lblbuscar_Click(object sender, EventArgs e)
        {

        }
        public static double busqueda(double buscarnum, ListBox lista)
        {
            int conteo = 0;
            foreach (var buscar in lista.Items)
            {
                if(Convert.ToDouble(buscar)==buscarnum)
                {
                    conteo++;
                }
            }
            return conteo;
}
        private void lstnumeros_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
