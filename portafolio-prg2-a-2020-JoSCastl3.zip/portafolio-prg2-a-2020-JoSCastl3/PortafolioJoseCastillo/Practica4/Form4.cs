﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnmayor_Click(object sender, EventArgs e)
        {

            if (txtnum1.Text == "" && txtnum2.Text == "" && txtnum3.Text == "")
            {
                MessageBox.Show("ingrese al menos dos numeros para comparar");
            }
            else if (txtnum1.Text == "" && txtnum2.Text == "" || txtnum2.Text == "" && txtnum3.Text == "" || txtnum1.Text == "" && txtnum3.Text == "")
            {
                MessageBox.Show("Es necesario al menos otro numero para comparar");
            }
            else if (txtnum1.Text != "" && txtnum2.Text != "" && txtnum3.Text != "")
            {
                int n1 = Convert.ToInt32(txtnum1.Text);
                int n2 = Convert.ToInt32(txtnum2.Text);
                int n3 = Convert.ToInt32(txtnum3.Text);
                lblmayor.Text = "el numero mayor es " + Convert.ToString(mayor(n1, n2,n3));
            }
            else
            {
                if (txtnum1.Text != "" && txtnum2.Text != "" && txtnum3.Text == "")
                {
                    int n1 = Convert.ToInt32(txtnum1.Text);
                    int n2 = Convert.ToInt32(txtnum2.Text);
                    if(n1==n2)
                    {
                        MessageBox.Show("los numeros son iguales no hay nada que comparar");
                        lblmayor.Text = "";
                    }
                    else
                    lblmayor.Text = "el numero mayor es " + Convert.ToString(mayor(n1, n2));
                }
                else if (txtnum1.Text != "" && txtnum2.Text == "" && txtnum3.Text != "")
                {
                    int n1 = Convert.ToInt32(txtnum1.Text);
                    int n3 = Convert.ToInt32(txtnum3.Text);
                    if(n1==n3)
                    {
                        MessageBox.Show("los numeros son iguales no hay nada que comparar");
                        lblmayor.Text = "";
                    }
                    else
                        lblmayor.Text = "el numero mayor es " + Convert.ToString(mayor(n1, n3));
                }
                else if (txtnum1.Text == "" && txtnum2.Text != "" && txtnum3.Text != "")
                {
                    int n3 = Convert.ToInt32(txtnum3.Text);
                    int n2 = Convert.ToInt32(txtnum2.Text);
                    if (n3 == n2)
                    {
                        MessageBox.Show("los numeros son iguales no hay nada que comparar");
                        lblmayor.Text = "";
                    }
                    else
                        lblmayor.Text = "el numero mayor es " + Convert.ToString(mayor(n2, n3));
                }
                else if(txtnum1.Text==txtnum2.Text && txtnum2.Text==txtnum3.Text)
                {
                    MessageBox.Show("los numeros son iguales no hay nada que comparar");
                    lblmayor.Text = "";
                }
            }

        }
        public static int mayor(int n1, int n2)
        {
            if (n1 < n2)
                return n2;
            else
                return n1;
        }
        public static int mayor(int n1, int n2, int n3)
        {
            if (n1 > n2 && n1 > n3)
            {
                return n1;
            }
            else if (n2 > n1 && n2 > n3)
            {
                return n2;
            }
            else
                return n3;
        }
    }
}


