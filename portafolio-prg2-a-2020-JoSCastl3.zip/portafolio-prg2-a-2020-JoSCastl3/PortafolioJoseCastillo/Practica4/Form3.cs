﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = Convert.ToInt32(txtnumero.Text);
                txtfibonacci.Text = Convert.ToString(Calculofibo(numero));
            }
            catch(Exception)
            {
                MessageBox.Show("ingrese solo numeros");
            }
        }
        public static int Calculofibo( int n1)
        {

            if (n1 < 2)
                return 2;
            else
                return Calculofibo(n1 - 1) + Calculofibo(n1 - 2);
        }
    }
}
