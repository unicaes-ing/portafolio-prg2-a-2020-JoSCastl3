﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsumar_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = Convert.ToDouble(txtnum1.Text);
                double num2 = Convert.ToDouble(txtnum2.Text);
                double num3 = Convert.ToDouble(txtnum3.Text);
                double num4 = Convert.ToDouble(txtnum4.Text);
                lblsumar.Text = "La suma es :"+Convert.ToString(Sumadex(num1, num2, num3, num4));
            }
            catch (Exception)
            {
                MessageBox.Show("Todos los datos deben ser numeros");
            }

        }
        public static double Sumadex(double n1, double n2, double n3, double n4)
        {
            double suma = n1 + n2 + n3 + n4;
            return suma;
        }
    }
}
